function Shooter(cv){const g=cv.getContext('2d');
const P=[[0,400,2400,50],[200,300,150,14],[500,230,180,14],[800,310,200,14],[1100,220,180,14],[1400,300,200,14],[1700,240,180,14],[1950,330,150,14]];
let me,bots,bl,score=0,cam=0,cd=0;
const spawn=()=>bots.push({x:500+Math.random()*1800,y:50,vx:0,vy:0,hp:40,w:20,h:30,cd:60});
function reset(){me={x:100,y:300,vx:0,vy:0,hp:100,fuel:100,w:20,h:30};bots=[];bl=[];for(let i=0;i<5;i++)spawn()}
function phys(o){o.g=0;o.vy+=.4;o.x+=o.vx;o.y+=o.vy;
for(const p of P)if(o.x+o.w>p[0]&&o.x<p[0]+p[2]&&o.y+o.h>=p[1]&&o.y+o.h-o.vy<=p[1]+1&&o.vy>=0){o.y=p[1]-o.h;o.vy=0;o.g=1}
o.x=Math.max(0,Math.min(2380,o.x));if(o.y>600)o.y=0}
const fire=(o,a,own)=>bl.push({x:o.x+10,y:o.y+12,vx:Math.cos(a)*10,vy:Math.sin(a)*10,own,l:60});
const hit=(b,o)=>b.x>o.x&&b.x<o.x+o.w&&b.y>o.y&&b.y<o.y+o.h;
reset();
return loop(()=>{
me.vx*=.85;if(K.a)me.vx=-3.5;if(K.d)me.vx=3.5;
if(K.w&&me.fuel>0){me.vy-=.7;me.fuel-=.8}else if(me.g)me.fuel=Math.min(100,me.fuel+1.5);
phys(me);cam=Math.max(0,Math.min(1600,me.x-400));
const a=Math.atan2(M.y-(me.y+12),M.x+cam-(me.x+10));
if(M.d&&cd--<=0){fire(me,a,1);cd=8}
for(const b of bots){const dx=me.x-b.x;b.vx=Math.abs(dx)>200?Math.sign(dx)*1.2:0;if(b.g&&Math.random()<.01)b.vy=-9;phys(b);
if(--b.cd<=0&&Math.abs(dx)<450){fire(b,Math.atan2(me.y-b.y,dx)+(Math.random()-.5)*.3,0);b.cd=50}}
for(const b of bl){b.x+=b.vx;b.y+=b.vy;b.l--;
if(b.own){for(const o of bots)if(b.l>0&&hit(b,o)){o.hp-=10;b.l=0;if(o.hp<=0){score++;o.dead=1}}}
else if(b.l>0&&hit(b,me)){me.hp-=6;b.l=0}}
bl=bl.filter(b=>b.l>0);const n=bots.length;bots=bots.filter(o=>!o.dead);while(bots.length<5)spawn();
if(me.hp<=0){score=0;reset()}
g.fillStyle='#6ec6ff';g.fillRect(0,0,800,450);
g.save();g.translate(-cam,0);
g.fillStyle='#4a7a3a';for(const p of P)g.fillRect(...p);
for(const o of bots){g.fillStyle='#d33';g.fillRect(o.x,o.y,o.w,o.h)}
g.fillStyle='#2a4bd6';g.fillRect(me.x,me.y,me.w,me.h);
g.strokeStyle='#222';g.lineWidth=4;g.beginPath();g.moveTo(me.x+10,me.y+12);g.lineTo(me.x+10+Math.cos(a)*22,me.y+12+Math.sin(a)*22);g.stroke();
g.fillStyle='#ff0';for(const b of bl)g.fillRect(b.x-2,b.y-2,4,4);
g.restore();
g.fillStyle='#000a';g.fillRect(10,10,204,40);g.fillStyle='#e33';g.fillRect(12,12,me.hp*2,14);g.fillStyle='#fc3';g.fillRect(12,30,me.fuel*2,14);
g.fillStyle='#fff';g.font='16px sans-serif';g.fillText('Kills: '+score,730,28);
})}
