const K={},M={x:0,y:0,d:false,r:false};
const cv=document.getElementById('c'),menu=document.getElementById('menu'),back=document.getElementById('back');
addEventListener('keydown',e=>{K[e.key.toLowerCase()]=1;if(e.key===' ')e.preventDefault()});
addEventListener('keyup',e=>K[e.key.toLowerCase()]=0);
const pos=e=>{const r=cv.getBoundingClientRect();M.x=(e.clientX-r.left)*800/r.width;M.y=(e.clientY-r.top)*450/r.height};
cv.addEventListener('pointermove',pos);
cv.addEventListener('pointerdown',e=>{pos(e);(e.pointerType==='mouse'&&e.button)?M.r=true:M.d=true});
addEventListener('pointerup',()=>{M.d=M.r=false});
addEventListener('pointercancel',()=>{M.d=M.r=false});
cv.addEventListener('contextmenu',e=>e.preventDefault());
function loop(f){let id,on=true;(function t(){if(!on)return;f();id=requestAnimationFrame(t)})();return()=>{on=false;cancelAnimationFrame(id)}}
let stop=null;
const games={shooter:()=>Shooter(cv),city:()=>City(cv),blocks:()=>Blocks(cv)};
const pad=document.getElementById('pad'),rot=document.getElementById('rot');
const touch=matchMedia('(pointer:coarse)').matches;
const PADS={shooter:[['◀','a','l1'],['▶','d','l2'],['▲','w','r1']],
city:[['◀','a','l1'],['▶','d','l2'],['▲','w','r1'],['▼','s','r3']],
blocks:[['◀','a','l1'],['▶','d','l2'],['▲','w','r1'],['⛏','place','t']]};
function buildPad(n){pad.innerHTML='';for(const[t,k,cls]of PADS[n]){const b=document.createElement('button');b.textContent=t;b.className=cls;
if(cls==='t'){b.onclick=()=>{K[k]=!K[k];b.textContent=K[k]?'▦':'⛏';b.classList.toggle('on',!!K[k])}}
else{const on=e=>{e.preventDefault();K[k]=1;b.classList.add('on')},off=()=>{K[k]=0;b.classList.remove('on')};
b.addEventListener('pointerdown',on);['pointerup','pointercancel','pointerleave'].forEach(v=>b.addEventListener(v,off))}
pad.appendChild(b)}}
document.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{menu.hidden=true;cv.hidden=false;back.hidden=false;stop=games[b.dataset.g]();if(touch){buildPad(b.dataset.g);pad.hidden=false;rot.hidden=false;const d=document.documentElement;d.requestFullscreen&&d.requestFullscreen().catch(()=>{});screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})}});
back.onclick=()=>{stop&&stop();stop=null;for(const k in K)K[k]=0;pad.hidden=true;rot.hidden=true;document.fullscreenElement&&document.exitFullscreen();menu.hidden=false;cv.hidden=true;back.hidden=true};
