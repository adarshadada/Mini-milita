function City(cv){const g=cv.getContext('2d'),S=300,N=20,Wd=S*N;
const car={x:50,y:50,a:0,v:0,hp:100};let cash=0,wanted=0,wt=0,cops=[],peds=[];
const bld=(x,y)=>x<0||y<0||x>=Wd||y>=Wd||(x%S>=110&&y%S>=110);
const mkPed=()=>({x:Math.random()*Wd,y:Math.floor(Math.random()*N)*S+50,d:Math.random()<.5?-1:1});
for(let i=0;i<80;i++)peds.push(mkPed());
function reset(){car.x=car.y=50;car.v=0;car.hp=100;cash=0;wanted=0;cops=[]}
return loop(()=>{
if(K.w)car.v+=.15;if(K.s)car.v-=.12;car.v*=.985;
car.a+=((K.d?1:0)-(K.a?1:0))*.05*Math.max(-1,Math.min(1,car.v/2));
const nx=car.x+Math.cos(car.a)*car.v,ny=car.y+Math.sin(car.a)*car.v;
if(bld(nx,ny)){car.v*=-.4;car.hp-=1}else{car.x=nx;car.y=ny}
for(const p of peds){p.x=(p.x+p.d*.6+Wd)%Wd;
if(Math.hypot(p.x-car.x,p.y-car.y)<18&&Math.abs(car.v)>1){Object.assign(p,mkPed());cash+=10;wanted=Math.min(5,wanted+1);wt=600}}
if(wanted>0&&--wt<=0){wanted--;wt=600;cops.pop()}
while(cops.length<wanted){const a=Math.random()*6.28;cops.push({x:car.x+Math.cos(a)*500,y:car.y+Math.sin(a)*500,a:0})}
for(const c of cops){c.a=Math.atan2(car.y-c.y,car.x-c.x);const s=2.2+wanted*.2;c.x+=Math.cos(c.a)*s;c.y+=Math.sin(c.a)*s;
if(Math.hypot(c.x-car.x,c.y-car.y)<22)car.hp-=.3}
if(car.hp<=0)reset();
const cx=Math.max(0,Math.min(Wd-800,car.x-400)),cy=Math.max(0,Math.min(Wd-450,car.y-225));
g.fillStyle='#3b3b44';g.fillRect(0,0,800,450);
g.save();g.translate(-cx,-cy);
for(let i=Math.floor(cx/S);i<=(cx+800)/S;i++)for(let j=Math.floor(cy/S);j<=(cy+450)/S;j++){
g.fillStyle='hsl('+((i*47+j*91)%360)+',25%,'+(35+(i*13+j*7)%20)+'%)';g.fillRect(i*S+110,j*S+110,180,180);
g.fillStyle='#ddd8';g.fillRect(i*S,j*S+48,S,4);g.fillRect(i*S+48,j*S,4,S)}
g.fillStyle='#ffd35a';for(const p of peds)g.fillRect(p.x-3,p.y-3,6,6);
const box=(o,c)=>{g.save();g.translate(o.x,o.y);g.rotate(o.a);g.fillStyle=c;g.fillRect(-14,-8,28,16);g.fillStyle='#9df';g.fillRect(2,-6,6,12);g.restore()};
for(const c of cops)box(c,(Date.now()>>8)%2?'#36f':'#f33');
box(car,'#e0457b');g.restore();
g.fillStyle='#000a';g.fillRect(10,10,150,50);g.fillStyle='#e33';g.fillRect(12,12,Math.max(0,car.hp)*1.46,10);
g.fillStyle='#fff';g.font='14px sans-serif';g.fillText('Cash $'+cash,14,40);g.fillText('Wanted '+'*'.repeat(wanted),14,56);
})}
