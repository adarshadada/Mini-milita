function Blocks(cv){const g=cv.getContext('2d'),T=32,W=200,H=60;
const C=[0,'#5a9e3a','#8b5a2b','#777','#6b4423','#2e7d32','#c8a063'],m=[];
for(let x=0;x<W;x++){m[x]=[];const h=Math.floor(26+Math.sin(x/9)*4+Math.sin(x/3.1)*1.5);for(let y=0;y<H;y++)m[x][y]=y<h?0:y==h?1:y<h+4?2:3}
for(let x=5;x<W-5;x+=7+Math.floor(Math.random()*5)){let y=0;while(!m[x][y])y++;
for(let i=1;i<=4;i++)m[x][y-i]=4;for(let dx=-2;dx<=2;dx++)for(let dy=-2;dy<=0;dy++)if(!m[x+dx][y-5+dy])m[x+dx][y-5+dy]=5}
const p={x:100*T,y:0,vx:0,vy:0,w:22,h:28,on:0};let sel=1,cd=0;
const solid=(x,y)=>x<0||x>=W||y>=H||(y>=0&&m[x][y]>0);
function hit(){for(let x=Math.floor(p.x/T);x<=Math.floor((p.x+p.w-1)/T);x++)for(let y=Math.floor(p.y/T);y<=Math.floor((p.y+p.h-1)/T);y++)if(solid(x,y))return 1}
return loop(()=>{
for(let i=1;i<=6;i++)if(K[i])sel=i;
p.vx=(K.d?3:0)-(K.a?3:0);p.vy=Math.min(p.vy+.5,12);
p.x+=p.vx;if(hit())p.x-=p.vx;
p.on=0;p.y+=p.vy;if(hit()){p.y-=p.vy;if(p.vy>0)p.on=1;p.vy=0}
if(K.w&&p.on)p.vy=-9.5;
const cx=Math.max(0,Math.min(W*T-800,p.x-400)),cy=Math.max(0,Math.min(H*T-450,p.y-225));
const tx=Math.floor((M.x+cx)/T),ty=Math.floor((M.y+cy)/T);
const near=Math.hypot(tx*T+16-p.x-11,ty*T+16-p.y-14)<T*6&&tx>=0&&tx<W&&ty>=0&&ty<H;
if(cd>0)cd--;
if(near&&cd==0){if(M.d&&m[tx][ty]){m[tx][ty]=0;cd=6}
else if(M.r&&!m[tx][ty]){m[tx][ty]=sel;if(hit())m[tx][ty]=0;else cd=6}}
g.fillStyle='#8fd3ff';g.fillRect(0,0,800,450);
for(let x=Math.floor(cx/T);x<=(cx+800)/T&&x<W;x++)for(let y=Math.floor(cy/T);y<=(cy+450)/T&&y<H;y++){const b=m[x][y];if(!b)continue;
g.fillStyle=C[b];g.fillRect(x*T-cx,y*T-cy,T,T);g.strokeStyle='#0003';g.strokeRect(x*T-cx+.5,y*T-cy+.5,T-1,T-1)}
g.fillStyle='#2a4bd6';g.fillRect(p.x-cx,p.y-cy,p.w,p.h);
if(near){g.strokeStyle='#fff';g.strokeRect(tx*T-cx,ty*T-cy,T,T)}
for(let i=1;i<=6;i++){g.fillStyle=C[i];g.fillRect(250+i*50,400,36,36);g.strokeStyle=i==sel?'#fff':'#000';g.lineWidth=3;g.strokeRect(250+i*50,400,36,36);g.lineWidth=1}
})}
