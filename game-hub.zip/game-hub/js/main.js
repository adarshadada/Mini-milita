const K={},M={x:0,y:0,d:false,r:false};
const cv=document.getElementById('c'),menu=document.getElementById('menu'),back=document.getElementById('back');
addEventListener('keydown',e=>{K[e.key.toLowerCase()]=1;if(e.key===' ')e.preventDefault()});
addEventListener('keyup',e=>K[e.key.toLowerCase()]=0);
cv.addEventListener('mousemove',e=>{const r=cv.getBoundingClientRect();M.x=(e.clientX-r.left)*800/r.width;M.y=(e.clientY-r.top)*450/r.height});
cv.addEventListener('mousedown',e=>{e.button?M.r=true:M.d=true});
addEventListener('mouseup',()=>{M.d=M.r=false});
cv.addEventListener('contextmenu',e=>e.preventDefault());
function loop(f){let id,on=true;(function t(){if(!on)return;f();id=requestAnimationFrame(t)})();return()=>{on=false;cancelAnimationFrame(id)}}
let stop=null;
const games={shooter:()=>Shooter(cv),city:()=>City(cv),blocks:()=>Blocks(cv)};
document.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{menu.hidden=true;cv.hidden=false;back.hidden=false;stop=games[b.dataset.g]()});
back.onclick=()=>{stop&&stop();stop=null;menu.hidden=false;cv.hidden=true;back.hidden=true};
